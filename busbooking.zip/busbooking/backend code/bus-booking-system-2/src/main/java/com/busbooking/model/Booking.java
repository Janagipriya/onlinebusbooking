
package com.busbooking.model;

import jakarta.persistence.*;

public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userEmail;
    private Long busId;
    private int numSeats;
    private double totalFare;
}
