CREATE DATABASE bus_ticket_booking;
USE bus_ticket_booking;
CREATE TABLE users (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    role ENUM('USER', 'ADMIN') NOT NULL
);
CREATE TABLE buses (
    bus_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bus_name VARCHAR(100) NOT NULL,
    bus_type ENUM('AC', 'Non_AC', 'Sleeper', 'Semi_Sleeper') NOT NULL,
    total_seats INT NOT NULL
);
CREATE TABLE routes (
    route_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    distance_km INT NOT NULL,
    duration VARCHAR(50) NOT NULL,
    fare DOUBLE NOT NULL
);
CREATE TABLE schedules (
    schedule_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bus_id BIGINT NOT NULL,
    route_id BIGINT NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    available_seats INT NOT NULL,
    FOREIGN KEY (bus_id) REFERENCES buses(bus_id) ON DELETE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(route_id) ON DELETE CASCADE
);
INSERT INTO users (full_name, email, password, phone, role) VALUES
('Admin User', 'admin@example.com', 'admin123', '9876543210', 'ADMIN'),
('John Doe', 'john@example.com', 'password123', '9876543211', 'USER');
INSERT INTO buses (bus_name, bus_type, total_seats) VALUES
('Express Bus', 'AC', 40),
('Night Rider', 'Sleeper', 30),
('City Express', 'Non_AC', 50);
INSERT INTO routes (source, destination, distance_km, duration, fare) VALUES
('New York', 'Los Angeles', 4500, '48h', 150.00),
('San Francisco', 'Las Vegas', 900, '10h', 50.00),
('Chicago', 'Houston', 1600, '20h', 100.00);
INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, available_seats) VALUES
(1, 1, '2025-03-05 10:00:00', '2025-03-07 10:00:00', 40),
(2, 2, '2025-03-06 08:00:00', '2025-03-06 18:00:00', 30),
(3, 3, '2025-03-07 09:00:00', '2025-03-07 22:00:00', 50);
INSERT INTO bookings (user_id, schedule_id, seat_number, total_amount, booking_status, payment_status) VALUES
(2, 1, 12, 150.00, 'CONFIRMED', 'PAID'),
(2, 2, 5, 50.00, 'CONFIRMED', 'PAID');
CREATE VIEW bus_routes AS
SELECT b.bus_id, b.bus_name, b.bus_type, r.source, r.destination, r.fare
FROM buses b
JOIN schedules s ON b.bus_id = s.bus_id
JOIN routes r ON s.route_id = r.route_id;

SELECT * FROM bus_routes;
CREATE VIEW user_bookings AS
SELECT bk.booking_id, u.full_name, u.email, b.bus_name, r.source, r.destination, bk.seat_number, bk.total_amount, bk.booking_status
FROM bookings bk
JOIN users u ON bk.user_id = u.user_id
JOIN schedules s ON bk.schedule_id = s.schedule_id
JOIN buses b ON s.bus_id = b.bus_id
JOIN routes r ON s.route_id = r.route_id;
SELECT * FROM user_bookings;



